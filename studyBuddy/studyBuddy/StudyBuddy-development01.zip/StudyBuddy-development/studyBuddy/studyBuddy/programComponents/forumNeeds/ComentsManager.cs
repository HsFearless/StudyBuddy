﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studyBuddy
{
    class ComentsManager
    {
        public static Dictionary<string, string> commentsTextFiles = new Dictionary<string, string>();

        public static void AddNewFile(string problemsName, string textFilesName)
        {
            //commentsTextFiles.Add
        }
    }
}
