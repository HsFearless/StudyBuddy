using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studyBuddy.dataNeeds
{
    static class SessionLogingFormLogic//this time static ok
    {
    	 public static bool done = false;
    	public static bool success = false;
    	public static bool reacted = false;
    	public static Thread loginThread;
    	public static Thread reactThread;
    	
    	public static void LoginThreadsStartFor(Form form, ref int progressVal)
    	{
    		done = false;
    		success = false;
    		reacted = false;
			//loginThread
    		 //^thread
			loginThread = new Thread
			(
                delegate() 
				{ //^delegate
                        SessionLoginFormLogic.RunSessionLogin(
								ref progressVal); 
				}
			);
			logInThread.Start(); 
			
			//reactThread
			reactThread = new Thread
			(
                delegate() 
				{ //^delegate
                        SessionLoginFormLogic.ReactToSessionThread(
								form); 
				}
			);
			reactThread.Start();
    	}
    
        public static void RunSessionLogin(ref int progressVal)
        {
        	done = false;
           success = Auth.LogInUsingSession(ref progressVal);
           done = true;
           return;
        }
        
        public static void ReactToSessionLoginThread(Form form)
        {
        	while(done != true)
        		continue;
        	//finally it is done
        	if(!success)
        		mbox(Auth.error.Message());
        	reacted = true;
        	form.Close();
        }
        
        public static void Exit(bool wait=false)
        {
        	if(reacted)
        		return;
        	if(wait)
      	  {
        		loginThread.Wait();
        		reactThread.Wait();
    	    }
    		else
    		{	
    			loginThread.Abort();
    			reactThread.Abort();
    		}
        }
        
        public static bool SessionSuccess()
        {
        	if(done)
        		return success;
        }
    }
}
